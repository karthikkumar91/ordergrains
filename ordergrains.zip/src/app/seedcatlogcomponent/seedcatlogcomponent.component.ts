import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seedcatlogcomponent',
  templateUrl: './seedcatlogcomponent.component.html',
  styleUrls: ['./seedcatlogcomponent.component.css']
})
export class SeedcatlogcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

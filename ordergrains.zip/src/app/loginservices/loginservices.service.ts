import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {SignupcomponentComponent} from '../signupcomponent/signupcomponent.component';

@Injectable({
  providedIn: 'root'
})
export class LoginservicesService {

  

  constructor(private http:HttpClient) { }
  loginservice(email,password):Observable<any>{
  
    const url="http://localhost:8080/ordergrains/loginservlet?email="+email+"&password="+password;
    return this.http.get(url);
  }
  emailsubmitsignup(userdetails):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json'
      })
    };
   console.log("pandi------>",userdetails);
  return this.http.post("http://localhost:8080/ordergrains/signupservlet", userdetails, httpOptions);
//   const url="http://localhost:8080/ordergrains/signupservlet?username="+username+"+&password="+password+"+&email="+email+"&phone=";
//   const url="http://localhost:8080/ordergrains/signupservlet
//   return this.http.post<>


 }
}

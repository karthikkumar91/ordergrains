import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartpagecomponent',
  templateUrl: './cartpagecomponent.component.html',
  styleUrls: ['./cartpagecomponent.component.css']
})
export class CartpagecomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}


import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutcomponent',
  templateUrl: './aboutcomponent.component.html',
  styleUrls: ['./aboutcomponent.component.css']
})
export class AboutcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentcomponents',
  templateUrl: './paymentcomponents.component.html',
  styleUrls: ['./paymentcomponents.component.css']
})
export class PaymentcomponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import {ProductservicesService} from '../productservices/productservices.service';


@Component({
  selector: 'app-detailscomponents',
  templateUrl: './detailscomponents.component.html',
  styleUrls: ['./detailscomponents.component.css'],
  providers:[ProductservicesService]
})
export class DetailscomponentsComponent implements OnInit {

  public product:items[];
  constructor(private service:ProductservicesService) { }

  ngOnInit() 
  {
    this.productdetails();
  }
  productdetails()
  {
    this.service.productservices().subscribe(res=>
      {
      this.product=res;
      console.log("pig",this.product);
    
  });
  }
}
interface items{
id;
pic;
price;
pname;
specification;

}

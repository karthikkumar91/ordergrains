import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footercomponent',
  templateUrl: './footercomponent.component.html',
  styleUrls: ['./footercomponent.component.css']
})
export class FootercomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

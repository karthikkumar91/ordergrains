import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackcomponent',
  templateUrl: './feedbackcomponent.component.html',
  styleUrls: ['./feedbackcomponent.component.css']
})
export class FeedbackcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import {LoginservicesService} from'../loginservices/loginservices.service';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-logincomponent',
  templateUrl: './logincomponent.component.html',
  styleUrls: ['./logincomponent.component.css'],
  providers:[LoginservicesService]
})
export class LogincomponentComponent implements OnInit {

  constructor(private signinservice:LoginservicesService) { }
  public signin;
  ngOnInit() {
  }
  emailsubmit(userdetails)
    {
      this.signinservice.loginservice(userdetails.email,userdetails.password).subscribe(res=>
        {
          this.signin=res;
          console.log('this.signin=',res.email);
        });
      
        console.log('Template Driven data', userdetails);
    }
    
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeseedcomponent',
  templateUrl: './homeseedcomponent.component.html',
  styleUrls: ['./homeseedcomponent.component.css']
})
export class HomeseedcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}

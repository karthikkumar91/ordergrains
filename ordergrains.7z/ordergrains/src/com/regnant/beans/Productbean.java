package com.regnant.beans;

public class Productbean {
	private String id;
	private String pic;
	private String price;
	private String pname;
	private String specification;

	public Productbean(String id, String pic, String price, String pname, String specification) {
		this.id = id;
		this.pic = pic;
		this.price = price;
		this.pname = pname;
		this.specification = specification;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

}
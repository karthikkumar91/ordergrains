package com.regnant.utils;

public class constants {

	public static final String grainslist="grainslist";
	public static final String email="email";
	public static final String password="password";
}

package com.product.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.regnant.beans.Productbean;

public class ProductDAO {
	public static List<Productbean> getproducts() throws ClassNotFoundException, SQLException {
		Connection con = new Dbconnection().getconnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from ordergrains.productdetails");
		List<Productbean> list = new ArrayList<>();
		while (rs.next()) {
			
			String pid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String pname = rs.getString(4);
			String specification = rs.getString(5);
		 {
			Productbean pb = new Productbean(pid, pic, price, pname, specification);
			list.add(pb);
		}
		con.close();
		System.out.println(list);
		

	}
		return list;
	}
}

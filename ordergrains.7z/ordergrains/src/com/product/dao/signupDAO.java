package com.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.regnant.beans.Userbean;

public class signupDAO {
//         public static void signup(String username,String password,String email,String phone)
	public static void signup(Userbean ub)
         	{
        	 Connection con;
			try {
				con = Dbconnection.getconnection();
				
				System.out.println(ub.getEmail());
				
//				System.out.println(username);
//				System.out.println(password);
//				System.out.println(email);
//				System.out.println(phone);
				
				String sql="INSERT INTO ordergrains.userdata(username, \"password\", email, phone)VALUES(?,?,?,?);";
				
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setString(1, ub.getUsername());
				pstmt.setString(2, ub.getPassword());
				pstmt.setString(3, ub.getEmail());
				pstmt.setString(4, ub.getPhone());
				pstmt.executeUpdate();				
				
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	 
        	 
         	}
         
        	 
         
}

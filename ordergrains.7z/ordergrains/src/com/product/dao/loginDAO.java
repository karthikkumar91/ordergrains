package com.product.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.regnant.beans.Userbean;

public class loginDAO 
{
	public static boolean login(Userbean ub) throws ClassNotFoundException, SQLException {
		Connection con = Dbconnection.getconnection();
		Statement stmt = con.createStatement();
		//String email="sdfbsdkjfbkjds";
		
		ResultSet rsd=stmt.executeQuery("select password from ordergrains.userdata where email='"+ub.getEmail()+"';");
		
//		ResultSet rs = stmt.executeQuery("select password from ordergrains.userdata where email='" + email + "';");
//		System.out.println("logindao   :::   "+password + email);
		String p = "";
//		while (rs.next()) {
//			System.out.println("hhjhhhh   "+ rs.getString(1));
//			p = rs.getString(1);
//			System.out.println("to chesk status : "+p);
//		}
//		System.out.println("result set data status :: "+rsd.next());
		while (rsd.next()) {
			p = rsd.getString(1);
			System.out.println("to chesk status : "+p);
		}
		
		if (p.equals(ub.getPassword())) {
			return true;
		} else {
			return false;
		}
		}
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


package com.reganant.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gains.email.EmailUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.product.dao.signupDAO;
import com.regnant.beans.Userbean;

/**
 * Servlet implementation class signupservlet
 */
@WebServlet("/signupservlet")
public class signupservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public signupservlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Gson gson = new Gson();

		/// response.setContentType("signupservlet/register");

		StringBuilder sb = new StringBuilder();
		String s;
		while ((s = request.getReader().readLine()) != null) {
			sb.append(s);
		}

		Userbean ub = (Userbean) gson.fromJson(sb.toString(), Userbean.class);
		JsonObject json = new JsonObject();
//		String username = ub.getUsername();
//		String password = ub.getPassword();
//		String email = ub.getEmail();
//		String phone = ub.getPhone();
//		signupDAO.signup(username, password, email, phone);
		
		signupDAO.signup(ub);
		
		// json.get("email",email);
		// json.addProperty("password", password);
		response.getWriter().write(json.toString());

		// new Userbean(username, password, email, phone);
		// EmailUtils.sendMail(email);

		response.getWriter().write("ok");
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub3
//		Gson gson = new Gson();
//		StringBuilder sb = new StringBuilder();
//
//		Userbean ub = (Userbean) gson.fromJson(sb.toString(), Userbean.class);
//		JsonObject json = new JsonObject();
//		
//		response.getWriter().write(json.toString());
//		
		doGet(request, response);

	}

}
